from django.shortcuts import render
from Index.models import Classification,Navigation

# Create your views here.
def index(request):
    classification = Classification.objects.values()
    navigation = Navigation.objects.values()
    for i in navigation:
        i['classification_id'] = Classification.objects.get(id=i['classification_id']).name
    data = {}
    data['classification'] = classification
    data['navigation'] = navigation
    return render(request,'index.html',data)