from django.contrib import admin
from Index.models import Classification,Navigation

# Register your models here.
class ClassificationAdmin(admin.ModelAdmin):
    list_display = ['name','create']

class NavigationAdmin(admin.ModelAdmin):
    list_display = ['title','subtitle','href','classification','create']

admin.site.register(Classification,ClassificationAdmin)
admin.site.register(Navigation,NavigationAdmin)