from django.db import models

# Create your models here.
class Classification(models.Model):
    name = models.CharField(max_length=20)
    create = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.name

class Navigation(models.Model):
    title = models.CharField(max_length=20)
    subtitle = models.CharField(max_length=100)
    href = models.CharField(max_length=100)
    classification = models.ForeignKey(Classification, on_delete=models.CASCADE)
    create = models.DateTimeField(auto_now_add=True)